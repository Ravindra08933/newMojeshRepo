//package com.cg.scb.dto;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//@Entity
//@Table(name = "User")
//@Setter
//@Getter
//@AllArgsConstructor
//public class User
//{
//	
//	String username;
//	String password;
//	String name;
//	@Override
//	public String toString() {
//		return "Login [username=" + username + ", password=" + password + "]";
//	}
//	
//}
