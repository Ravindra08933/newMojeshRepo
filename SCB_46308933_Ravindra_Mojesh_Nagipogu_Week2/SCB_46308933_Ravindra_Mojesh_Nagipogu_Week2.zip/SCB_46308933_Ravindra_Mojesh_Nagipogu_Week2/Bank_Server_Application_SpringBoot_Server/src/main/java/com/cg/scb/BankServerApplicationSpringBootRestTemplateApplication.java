package com.cg.scb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankServerApplicationSpringBootRestTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankServerApplicationSpringBootRestTemplateApplication.class, args);
	}

}
