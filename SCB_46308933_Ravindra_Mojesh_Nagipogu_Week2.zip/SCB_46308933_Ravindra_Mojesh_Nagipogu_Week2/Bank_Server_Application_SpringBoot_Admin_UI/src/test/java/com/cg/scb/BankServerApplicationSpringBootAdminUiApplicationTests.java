package com.cg.scb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServerApplicationSpringBootAdminUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
